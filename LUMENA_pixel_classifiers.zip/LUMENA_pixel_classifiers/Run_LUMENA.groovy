selectAnnotations();
addPixelClassifierMeasurements("LUMENA_pixel_classifier", "LUMENA_pixel_classifier")