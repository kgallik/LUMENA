selectAnnotations();
runPlugin('qupath.lib.algorithms.TilerPlugin', '{"tileSizeMicrons":200.0,"trimToROI":true,"makeAnnotations":false,"removeParentAnnotation":false}')
selectTiles();
addPixelClassifierMeasurements("LUMENA_pixel_classifier", "LUMENA_pixel_classifier")
classifyDetectionsByCentroid("LUMENA_pixel_classifier")